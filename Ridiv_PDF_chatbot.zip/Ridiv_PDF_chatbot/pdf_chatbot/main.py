
import os
import openai
from fastapi import FastAPI, File, UploadFile, HTTPException, Body
from pydantic import BaseModel
import pdfplumber
from dotenv import load_dotenv
from fastapi.staticfiles import StaticFiles

# Set your OpenAI API key
openai.api_key = "sk-proj-BV24cUeIgc01q3yDYzaQT3BlbkFJTfVjYUEJv6ILCGLkzv1G"

# Initialize the FastAPI app
app = FastAPI()

# Mount the static files directory
app.mount("/static", StaticFiles(directory="static"), name="static")

class Query(BaseModel):
    question: str

def extract_text_from_pdf(file_path):
    try:
        with pdfplumber.open(file_path) as pdf:
            text = ''
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + '\n'
        return text
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error extracting text from PDF: {str(e)}")

def query_pdf_with_rag(pdf_text, user_query):
    try:
        response = openai.Completion.create(
            model="gpt-4",
            prompt=f"Answer the following question based on the given text:\n\nText: {pdf_text}\n\nQuestion: {user_query}",
            max_tokens=150
        )
        if response and response.choices:
            return response.choices[0].text.strip()
        else:
            raise HTTPException(status_code=500, detail="Invalid response from OpenAI API")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error querying OpenAI API: {str(e)}")

@app.post("/upload_pdf/")
async def upload_pdf(file: UploadFile = File(...)):
    try:
        if not file.filename.lower().endswith('.pdf'):
            raise HTTPException(status_code=400, detail="File must be a PDF")

        # Read the file content
        file_content = await file.read()

        # Log the filename and size of the uploaded file
        print("Uploaded file:", file.filename)
        print("File size:", len(file_content))

        # Create a temporary file to save the uploaded PDF
        with open('temp.pdf', 'wb') as temp_pdf:
            temp_pdf.write(file_content)

        # Extract text from the uploaded PDF
        pdf_text = extract_text_from_pdf('temp.pdf')

        # Remove the temporary PDF file
        os.remove('temp.pdf')

        return {"text": pdf_text}
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing the PDF file: {str(e)}")

@app.post("/query_pdf/")
async def query_pdf(query: Query = Body(...), pdf_text: str = Body(...)):
    try:
        response = query_pdf_with_rag(pdf_text, query.question)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
