# -*- coding: utf-8 -*-
import requests

# Define the URL of the API endpoint
url = "http://127.0.0.1:8000/query_pdf/"

# Define the JSON payload
payload = {
    "question": "What is the main programming language mentioned in the text?",
    "pdf_text": "D.ABIRAMI\nContact: +91 – 7094112264 2nd cross,Madiwala,Bangalore.\nMail: abidinesh250@gmail.com LinkedIn:www.linkedin.com/in/abirami-dhandapani-61b3a521a\nProfessional Summary\n Passionate Python Developer with 6 month of experience.\n Having strong knowledge of Develop and maintain Python-based applications and software systems.\n Integrate data from various sources and RESTful APIs.\nWork Experience and Project Summary\nPython Back-end Developer – Artivatic.AI,- Intern Bangalore\n Worked at the State Bank of India (SBI), managing tasks related to email verification. Users should be\nable to log in with their registered email IDs and verify them. Upon successful verification, a\nconfirmation message will be displayed.\n Utilized Python, Django Framework, MySQL, and REST API for implementation.\n Test cases were handled using Pytest with the provided URL, and proficient in testing tools such as\nPOSTMAN.\n I have created the video uploaded and Employee details in CRUD application using Python, Django,\nMySQL and REST API Framework\n Created two models in Django using Foreign Key constraint and I have linked two tables in single URL.\n Using Python script I have removed the background from an uploaded Image\nProgramming Languages\n Python\n MySQL, Django, Rest API\nCertification\n I recently completed a Python program at Palle Technology in Bangalore, where I refined my\nprogramming skills and delved deeper into Python's capabilities.\nEducation\n I have completed Bachelor of Engineering (CSE) at SKP Engineering College, Tiruvanamalai.\nI have provided are accurate to the best of my knowledge\n."
}

# Send the POST request
response = requests.post(url, json=payload)

# Print the response
print(response.json())
